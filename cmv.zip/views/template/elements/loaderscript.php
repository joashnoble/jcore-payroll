<script type="text/javascript">
    $(window).load(function(){
    	
        setTimeout(function() {
            $(".se-pre-con").fadeOut("slow");
            //alert("aw");
    
        }, 300);
    });
</script>