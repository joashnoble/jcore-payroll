<link type="text/css" href="assets/css/bootstrap.css" rel="stylesheet">
<link type="text/css" href="assets/css/animate.css" rel="stylesheet">
<link type="text/css" href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">

<link type="text/css" href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">        <!-- Font Awesome -->
<link type="text/css" href="assets/fonts/themify-icons/themify-icons.css" rel="stylesheet">              <!-- Themify Icons -->
<link type="text/css" href="assets/css/styles.css" rel="stylesheet">                                     <!-- Core CSS with all styles -->

<link type="text/css" href="assets/plugins/codeprettifier/prettify.css" rel="stylesheet">                <!-- Code Prettifier -->
<link type="text/css" href="assets/plugins/iCheck/skins/minimal/blue.css" rel="stylesheet">              <!-- iCheck -->


<link href="assets/plugins/notify/pnotify.core.css" rel="stylesheet"> <!-- notification -->
<link href="assets/css/pace.css" rel="stylesheet"> <!-- pace -->
<style>
	.datepicker{z-index:9999 !important}

</style>