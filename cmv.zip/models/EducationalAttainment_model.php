<?php

class EducationalAttainment_model extends CORE_Model {
    protected  $table="emp_educational_attainment";
    protected  $pk_id="emp_educational_attainment_id";

    function __construct() {
        parent::__construct();
    }



}
?>