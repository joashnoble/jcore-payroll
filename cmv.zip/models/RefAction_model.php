<?php

class RefAction_model extends CORE_Model {
    protected  $table="ref_action_taken";
    protected  $pk_id="ref_action_taken_id";

    function __construct() {
        parent::__construct();
    }



}
?>