<?php

class Employee_account_model extends CORE_Model {
    protected  $table="employee_account";
    protected  $pk_id="employee_account_id";

    function __construct() {
        parent::__construct();
    }
}
?>
