<?php

class GeneralSettings_model extends CORE_Model {
    protected  $table="company_setup";
    protected  $pk_id="company_id";

    function __construct() {
        parent::__construct();
    }
}
?>