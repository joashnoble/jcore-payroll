<?php

class RefEmploymentType_model extends CORE_Model {
    protected  $table="ref_employment_type";
    protected  $pk_id="ref_employment_type_id";

    function __construct() {
        parent::__construct();
    }



}
?>