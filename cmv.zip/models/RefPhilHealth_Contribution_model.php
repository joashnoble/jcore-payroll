<?php

class RefPhilHealth_Contribution_model extends CORE_Model {
    protected  $table="ref_philhealth_contribution";
    protected  $pk_id="ref_philhealth_contribution_id";

    function __construct() {
        parent::__construct();
    }
}
?>