<?php

class RefRelationship_model extends CORE_Model {
    protected  $table="ref_relationship";
    protected  $pk_id="ref_relationship_id";

    function __construct() {
        parent::__construct();
    }



}
?>