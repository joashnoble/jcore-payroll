<?php

class RefCompensation_model extends CORE_Model {
    protected  $table="ref_compensation_type";
    protected  $pk_id="ref_compensation_type_id";

    function __construct() {
        parent::__construct();
    }



}
?>