<?php

class RefFactorFile_model extends CORE_Model {
    protected  $table="reffactorfile";
    protected  $pk_id="factor_id";

    function __construct() {
        parent::__construct();
    }
}
?>