<?php

class RefSSS_Contribution_model extends CORE_Model {
    protected  $table="ref_sss_contribution";
    protected  $pk_id="ref_sss_contribution_id";

    function __construct() {
        parent::__construct();
    }
}
?>