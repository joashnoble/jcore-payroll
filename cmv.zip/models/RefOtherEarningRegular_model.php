<?php

class RefOtherEarningRegular_model extends CORE_Model {
    protected  $table="new_otherearnings_regular";
    protected  $pk_id="oe_regular_id";

    function __construct() {
        parent::__construct();
    }
}
?>