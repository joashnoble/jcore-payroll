<?php

class Email_user_settings_model extends CORE_Model {
    protected  $table="email_user_settings";
    protected  $pk_id="email_user_settings_id";

    function __construct() {
        parent::__construct();
    }




}
?>
