<?php

class PaySlip_earning_model extends CORE_Model {
    protected  $table="pay_slip_other_earnings";
    protected  $pk_id="pay_slip_other_earnings_id";

    function __construct() {
        parent::__construct();
    }
}
?>