<?php

class Payslip_model extends CORE_Model {
    protected  $table="pay_slip";
    protected  $pk_id="pay_slip_id";

    function __construct() {
        parent::__construct();
    }



}
?>