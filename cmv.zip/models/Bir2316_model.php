<?php

class Bir2316_model extends CORE_Model {
    protected  $table="bir_2316";
    protected  $pk_id="bir_2316_id";

    function __construct() {
        parent::__construct();
    }



}
?>