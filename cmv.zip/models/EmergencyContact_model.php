<?php

class EmergencyContact_model extends CORE_Model {
    protected  $table="emp_emergency_contact_details";
    protected  $pk_id="emp_emergency_contact_details_id";

    function __construct() {
        parent::__construct();
    }



}
?>