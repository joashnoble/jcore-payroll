<?php

class ChildrenDependent_model extends CORE_Model {
    protected  $table="emp_children_dependent";
    protected  $pk_id="emp_children_dependent_id";

    function __construct() {
        parent::__construct();
    }



}
?>