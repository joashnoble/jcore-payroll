<?php

class RefEarningType_model extends CORE_Model {
    protected  $table="refotherearningstype";
    protected  $pk_id="earnings_type_id";

    function __construct() {
        parent::__construct();
    }



}
?>