<?php

class RefDuration_model extends CORE_Model {
    protected  $table="ref_duration";
    protected  $pk_id="duration_id";

    function __construct() {
        parent::__construct();
    }
}
?>