<?php

class RefEarningSetup_model extends CORE_Model {
    protected  $table="refotherearnings";
    protected  $pk_id="earnings_id";

    function __construct() {
        parent::__construct();
    }
}
?>