<?php

class RefDiscipline_model extends CORE_Model {
    protected  $table="ref_disciplinary_action_policy";
    protected  $pk_id="ref_disciplinary_action_policy_id";

    function __construct() {
        parent::__construct();
    }



}
?>