<?php

class FamilyDetails_model extends CORE_Model {
    protected  $table="emp_family_details";
    protected  $pk_id="emp_family_details_id";

    function __construct() {
        parent::__construct();
    }



}
?>