<?php

class RefGroup_model extends CORE_Model {
    protected  $table="refgroup";
    protected  $pk_id="group_id";

    function __construct() {
        parent::__construct();
    }
}
?>