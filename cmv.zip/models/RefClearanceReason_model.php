<?php
class RefClearanceReason_model extends CORE_Model {
    protected  $table="ref_clearance_reason";
    protected  $pk_id="clearance_reason_id";

    function __construct() {
        parent::__construct();
    }
}
?>