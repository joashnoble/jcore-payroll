<?php

class RefBranch_model extends CORE_Model {
    protected  $table="ref_branch";
    protected  $pk_id="ref_branch_id";
    protected  $tabletocheck="emp_rates_duties";

    function __construct() {
        parent::__construct();
    }

    


}
?>