<?php

class RefReligion_model extends CORE_Model {
    protected  $table="ref_religion";
    protected  $pk_id="ref_religion_id";
    protected  $tabletocheck="employee_list";


    function __construct() {
        parent::__construct();
    }



}
?>