<?php

class SchedRefDayType_model extends CORE_Model {
    protected  $table="ref_day_type";
    protected  $pk_id="ref_day_type_id";

    function __construct() {
        parent::__construct();
    }




}
?>
