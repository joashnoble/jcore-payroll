<?php

class RefDtrDeduction_model extends CORE_Model {
    protected  $table="dtr_deductions";
    protected  $pk_id="dtr_deduction_id";

    function __construct() {
        parent::__construct();
    }
}
?>