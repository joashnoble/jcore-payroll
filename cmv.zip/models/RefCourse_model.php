<?php

class RefCourse_model extends CORE_Model {
    protected  $table="ref_course_degree";
    protected  $pk_id="ref_course_degree_id";

    function __construct() {
        parent::__construct();
    }



}
?>