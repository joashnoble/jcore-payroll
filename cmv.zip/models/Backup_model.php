<?php

class Backup_model extends CORE_Model {
    protected  $table="backup";
    protected  $pk_id="backup_id";

    function __construct() {
        parent::__construct();
    }




}
?>
