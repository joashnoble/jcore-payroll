<?php

class AdjustmentsClosing_model extends CORE_Model {
    protected  $table="pay_slip_loans_adjustments";
    protected  $pk_id="loans_adjustments_id";
    protected  $tabletocheck="";

    function __construct() {
        parent::__construct();
    }

    


}
?>