<?php

class RefDeductionType_model extends CORE_Model {
    protected  $table="refdeductiontype";
    protected  $pk_id="deduction_type_id";

    function __construct() {
        parent::__construct();
    }



}
?>