<?php

class SchedTemplate_model extends CORE_Model {
    protected  $table="schedule_template";
    protected  $pk_id="schedule_template_id";

    function __construct() {
        parent::__construct();
    }



}
?>
