<?php

class RefCertificate_model extends CORE_Model {
    protected  $table="ref_certificate";
    protected  $pk_id="ref_certificate_id";

    function __construct() {
        parent::__construct();
    }



}
?>